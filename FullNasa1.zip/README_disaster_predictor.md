# Disaster Risk Prediction System

This project analyzes NASA-style environmental CSV/CVV files, detects significant changes, and estimates disaster risk using a DNN.

## Input

Put your data files here:

    data/

Supported extensions:

    .csv
    .cvv
    .txt

Required columns:

    date
    one or more numeric environmental variables

Optional columns:

    region
    lat
    lon
    label / disaster_label / event / target

If no label column is present, proxy labels are created from statistical extremes.

## Run

    python full_disaster_predictor.py

## Outputs

    output/trend_report.csv
    output/trends.png
    output/trend_map_*.png
    output/future_risk.csv
    output/future_risk.png
    output/risk_model.pkl
    output/scaler.pkl

## Dashboard

Optional Streamlit dashboard:

    pip install streamlit
    streamlit run dashboard.py